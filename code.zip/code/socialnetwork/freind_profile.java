public class freind_profile

public static void main(String args[])
{
System.out.print( "Connect with your freinds"  );
{
Scanner s = new Scanner(System.in);
char freind_name = s.next().charAt(0);
   char freind_name= 'a';

      switch(freind_name)
      {
         case 'a' :
            System.out.println("opening a's profile"); 
            break;
        
         case 'b' :
            System.out.println("He is not your freind");
            break;
         case 'c' :
            System.out.println("He is not your freind");
         case 'd' :
            System.out.println("He is not your freind");
            break;
         default :
            System.out.println("you dont have any freinds");
      }
      System.out.println("Your have successfully opened his profile");
      
   }
}

public like

{

System.out.print( "$%$%$%$A'S DETAILS $%$%$%"  );
System.out.print( "A'S NEWSFEED"  );
System.out.print( "TO LIKE A'S NEWSFEED PRESS BUTTON 'L'   OR TO UNLIKE PRESS BUTTON 'U' " );
{
char button = s.next().charAt(0);

 switch(button)
      {
         case 'L' :
            System.out.println("YOU LIKED HIS NEWSFEED"); 
            break;
        
         case 'U' :
            System.out.println("YOU DISLIKED HIS NEWSFEED");
            break;
            
       }
     }
   }
















