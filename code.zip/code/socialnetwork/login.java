import java.util.*; 
import java.util.Scanner;


public class account_login

{
public static void main(String[] args)
{
Scanner s = new Scanner(System.in);
		System.out.print( "Enter your username: "  );
		String username = s.nextLine();
		System.out.println( "Hello " + username + "!" );
	
   	 System.out.print( "Enter your password"  );
     
       do
    {
       String password = s.nextLine();
       {
       if (password = abhijit)
       
         System.out.print("You have succesfully loggede in");
       
       break;
       
       else
       System.out.println( "Please try again");
       }
 
   while ( password = abhijit  ) ;
   
         System.out.print("You have succesfully loggede in");
         }
         
         
         System.out.print( "%$$%DETAILS%$%$ "  );
         
         
          
         
