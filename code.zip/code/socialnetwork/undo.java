public undo

{
System.out.print( "Do you want to undo anything ??"  );
{
Scanner s = new Scanner(System.in);
		System.out.print( "IF YES TYPE YES ELSE TYPE NO "  );
		String add= s.nextLine();
		
		if (add=yes)
		System.out.print( "YOU HAVE SUCCESSFULLY UNDONE"  );
		
		else
		System.out.print( "goodbye"  );
		
