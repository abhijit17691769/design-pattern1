public add_freind

{
System.out.print( "Do you want to add a  freind  or unfreind?"  );
{
Scanner s = new Scanner(System.in);
		System.out.print( "IF YES TYPE YES ELSE TO UNFREIND  NO! "  );
		String add= s.nextLine();
		
		{
		
		  if (add=yes)
		System.out.print( "Enter your the user's name "  );
		String freind_name= s.nextLine();
		System.out.print( "You are request has been sent to" + freind_name  );
		
		else
		
		{
		
		if (add=no)
		System.out.print( "Enter your freinds name "  );
		String freind_name= s.nextLine();
		System.out.print( "You unfreinded" + freind_name  );
		
		else
		break;
		}
		
		}
		}
		}
		
		
		
		
		
